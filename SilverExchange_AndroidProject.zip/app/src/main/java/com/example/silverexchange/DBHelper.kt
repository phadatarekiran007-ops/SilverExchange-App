package com.example.silverexchange

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*

class DBHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    companion object {
        private const val DB_NAME = "silver_exchange.db"
        private const val DB_VERSION = 1
        private const val TABLE = "transactions"
        private const val COL_ID = "id"
        private const val COL_BILL = "bill_no"
        private const val COL_CUST = "customer"
        private const val COL_WEIGHT = "weight_kg"
        private const val COL_PURITY = "purity"
        private const val COL_FINE = "fine_kg"
        private const val COL_MAKE = "making_charge"
        private const val COL_DATE = "date_str"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val sql = """CREATE TABLE $TABLE (
            $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COL_BILL TEXT,
            $COL_CUST TEXT,
            $COL_WEIGHT REAL,
            $COL_PURITY REAL,
            $COL_FINE REAL,
            $COL_MAKE REAL,
            $COL_DATE TEXT
        );"""
        db.execSQL(sql)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE")
        onCreate(db)
    }

    fun insertTransaction(t: Transaction): Long {
        val db = writableDatabase
        val cv = ContentValues()
        // auto-increment bill based on last id
        val lastId = getLastId()
        val nextBill = String.format("BILL-%04d", lastId+1)
        cv.put(COL_BILL, nextBill)
        cv.put(COL_CUST, t.customer)
        cv.put(COL_WEIGHT, t.weightKg)
        cv.put(COL_PURITY, t.purity)
        cv.put(COL_FINE, t.fineKg)
        cv.put(COL_MAKE, t.makingCharge)
        cv.put(COL_DATE, t.date)
        val id = db.insert(TABLE, null, cv)
        db.close()
        return id
    }

    fun getLastId(): Long {
        val db = readableDatabase
        val cur: Cursor = db.rawQuery("SELECT MAX($COL_ID) FROM $TABLE", null)
        var id: Long = 0
        if (cur.moveToFirst()) {
            id = cur.getLong(0)
        }
        cur.close()
        db.close()
        return id
    }

    fun getAll(): List<Transaction> {
        val list = mutableListOf<Transaction>()
        val db = readableDatabase
        val cur = db.rawQuery("SELECT * FROM $TABLE ORDER BY $COL_ID DESC", null)
        if (cur.moveToFirst()) {
            do {
                val t = Transaction()
                t.id = cur.getLong(cur.getColumnIndexOrThrow(COL_ID))
                t.billNo = cur.getString(cur.getColumnIndexOrThrow(COL_BILL))
                t.customer = cur.getString(cur.getColumnIndexOrThrow(COL_CUST))
                t.weightKg = cur.getDouble(cur.getColumnIndexOrThrow(COL_WEIGHT))
                t.purity = cur.getDouble(cur.getColumnIndexOrThrow(COL_PURITY))
                t.fineKg = cur.getDouble(cur.getColumnIndexOrThrow(COL_FINE))
                t.makingCharge = cur.getDouble(cur.getColumnIndexOrThrow(COL_MAKE))
                t.date = cur.getString(cur.getColumnIndexOrThrow(COL_DATE))
                list.add(t)
            } while (cur.moveToNext())
        }
        cur.close()
        db.close()
        return list
    }
}
