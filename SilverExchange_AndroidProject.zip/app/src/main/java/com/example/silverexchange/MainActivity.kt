package com.example.silverexchange

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DBHelper(this)

        val etCustomer = findViewById<EditText>(R.id.etCustomer)
        val etWeight = findViewById<EditText>(R.id.etWeight)
        val etPurity = findViewById<EditText>(R.id.etPurity)
        val btnCalculate = findViewById<Button>(R.id.btnCalculate)
        val btnHistory = findViewById<Button>(R.id.btnHistory)
        val tvFineSilver = findViewById<TextView>(R.id.tvFineSilver)
        val tvMakingCharge = findViewById<TextView>(R.id.tvMakingCharge)

        btnCalculate.setOnClickListener {
            val name = etCustomer.text.toString().trim()
            val weightText = etWeight.text.toString().trim()
            val purityText = etPurity.text.toString().trim()

            if (name.isEmpty()) {
                etCustomer.error = "Enter customer name"
                return@setOnClickListener
            }
            if (weightText.isEmpty()) {
                etWeight.error = "Enter weight in kg"
                return@setOnClickListener
            }
            if (purityText.isEmpty()) {
                etPurity.error = "Enter purity (%)"
                return@setOnClickListener
            }

            val weight = weightText.toDoubleOrNull()
            val purity = purityText.toDoubleOrNull()
            if (weight == null || weight <= 0.0) {
                etWeight.error = "Enter valid weight"
                return@setOnClickListener
            }
            if (purity == null || purity <= 0.0 || purity > 100.0) {
                etPurity.error = "Enter purity 0-100"
                return@setOnClickListener
            }

            val fine = (weight * purity) / 100.0
            val making = weight * 350.0

            tvFineSilver.text = String.format("Fine Silver (kg): %.3f", fine)
            tvMakingCharge.text = String.format("Making Charge (₹): %.2f", making)

            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            val dateStr = sdf.format(Date())

            val t = Transaction(0, "", name, weight, purity, fine, making, dateStr)
            val id = db.insertTransaction(t)
            if (id > 0) {
                Toast.makeText(this, "Saved (id=$id)", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show()
            }
        }

        btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        // Request storage permission for export (for older Androids)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 101)
            }
        }
    }
}
