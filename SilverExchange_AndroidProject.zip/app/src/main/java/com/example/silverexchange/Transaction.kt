package com.example.silverexchange

data class Transaction(
    var id: Long = 0,
    var billNo: String = "",
    var customer: String = "",
    var weightKg: Double = 0.0,
    var purity: Double = 0.0,
    var fineKg: Double = 0.0,
    var makingCharge: Double = 0.0,
    var date: String = ""
)
