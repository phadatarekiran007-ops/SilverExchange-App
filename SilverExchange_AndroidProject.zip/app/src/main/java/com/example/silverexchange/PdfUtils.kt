package com.example.silverexchange

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Environment
import java.io.File
import java.io.FileOutputStream

object PdfUtils {
    fun createSimpleReceipt(context: Context, t: Transaction): String? {
        return try {
            val doc = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(300, 400, 1).create()
            val page = doc.startPage(pageInfo)
            val canvas: Canvas = page.canvas
            val paint = Paint()
            paint.textSize = 10f
            var y = 20f
            canvas.drawText("Silver Exchange Receipt", 10f, y, paint); y += 20f
            canvas.drawText("Bill: ${t.billNo}", 10f, y); y += 15f
            canvas.drawText("Date: ${t.date}", 10f, y); y += 15f
            canvas.drawText("Customer: ${t.customer}", 10f, y); y += 15f
            canvas.drawText("Weight(kg): ${String.format("%.3f", t.weightKg)}", 10f, y); y += 15f
            canvas.drawText("Purity(%): ${String.format("%.2f", t.purity)}", 10f, y); y += 15f
            canvas.drawText("Fine(kg): ${String.format("%.3f", t.fineKg)}", 10f, y); y += 15f
            canvas.drawText("Making(₹): ${String.format("%.2f", t.makingCharge)}", 10f, y); y += 20f
            doc.finishPage(page)
            val path = context.getExternalFilesDir(null)
            val file = File(path, "receipt_${t.billNo}.pdf")
            val fos = FileOutputStream(file)
            doc.writeTo(fos)
            doc.close()
            fos.close()
            file.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
