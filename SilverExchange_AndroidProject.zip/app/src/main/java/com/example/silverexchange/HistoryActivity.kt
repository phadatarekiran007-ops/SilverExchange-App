package com.example.silverexchange

import android.os.Bundle
import android.os.Environment
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileWriter
import java.text.DecimalFormat

class HistoryActivity : AppCompatActivity() {

    lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        db = DBHelper(this)
        val lv = findViewById<ListView>(R.id.lvHistory)
        val btnExport = findViewById<Button>(R.id.btnExport)

        val list = db.getAll()
        val display = list.map {
            String.format("%s | %s | %.3f kg | ₹%.2f", it.billNo, it.customer, it.fineKg, it.makingCharge)
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, display)
        lv.adapter = adapter

        btnExport.setOnClickListener {
            exportCsv(list)
        }
    }

    private fun exportCsv(list: List<Transaction>) {
        try {
            val csvHeader = "BillNo,Customer,WeightKg,Purity,FineKg,MakingCharge,Date\n"
            val sb = StringBuilder()
            sb.append(csvHeader)
            for (t in list) {
                sb.append(String.format("%s,%s,%.3f,%.2f,%.3f,%.2f,%s\n",
                    t.billNo, t.customer.replace(","," "), t.weightKg, t.purity, t.fineKg, t.makingCharge, t.date))
            }
            val path = getExternalFilesDir(null)
            val file = File(path, "silver_history.csv")
            val fw = FileWriter(file)
            fw.write(sb.toString())
            fw.close()
            Toast.makeText(this, "CSV exported: ${file.absolutePath}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
